"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const AWS = __importStar(require("aws-sdk"));
const env = __importStar(require("./env"));
const envSlack = __importStar(require("./env/slack"));
const lambda = new AWS.Lambda({ region: env.region });
const send = async (message, channel) => {
    const text = typeof message === "object" ? JSON.stringify(message) : message;
    // チャンネル名が空文字かnoneだったらSlackへの送信はスキップ
    if (channel === "" || channel === "none") {
        console.log(text);
        return;
    }
    console.log(`Slackへ送信: channel=${channel}, message=${text}`);
    const payload = {
        text: text,
        channel: channel,
        name: envSlack.AccountNickName,
        icon: envSlack.Icon
    };
    await lambda
        .invoke({
        FunctionName: envSlack.ClientLambdaName,
        Payload: JSON.stringify(payload)
    })
        .promise();
};
exports.log = async (message) => {
    await send(message, envSlack.Channel);
};
exports.error = async (message) => {
    await send(message, envSlack.ErrorChannel);
};
