"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const amiDeregistration = __importStar(require("./amiDeregistration"));
const rds = __importStar(require("./rds"));
const ec2 = __importStar(require("./ec2"));
exports.generateTasks = async (hours, now) => {
    const generators = [ec2.generateTasks, rds.generateTasks, amiDeregistration.generateTasks];
    let result = [];
    for (const generator of generators) {
        const tasks = await generator(hours, now);
        result = result.concat(tasks);
    }
    return result;
};
