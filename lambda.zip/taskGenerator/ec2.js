"use strict";
/**
 * EC2起動・停止、ステータスチェック、AMI登録・AMIタグ追加のタスクを生成する
 */
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const AWS = __importStar(require("aws-sdk"));
const env = __importStar(require("../env/index"));
const toolbox = __importStar(require("aws-toolbox"));
const moment_1 = __importDefault(require("moment"));
const util = __importStar(require("../util"));
const ec2 = new AWS.EC2({ region: env.region });
/**
 * EC2インスタンスのタグ情報からAMI登録タスクを生成する
 * @param instances EC2インスタンスのリスト
 * @param forceToReboot AMI作成時に強制リブートをかけるならtrue
 * @param hours タスクを生成する範囲
 * @param now タスクを生成する基準となる日時。省略時は現在時刻
 */
exports.generateAmiRegistrationTasks = (instances, forceToReboot, hours, now) => {
    const tagName = forceToReboot ? "AmiSchedule_ForceToReboot" : "AmiSchedule";
    const source = instances.map(x => util.generateTask(x, tagName, "RegisterAmi", hours, now)).flat();
    return source.map(x => {
        return {
            key: "",
            task: "RegisterAmi",
            resourceType: "EC2",
            scheduledTime: util.formatMomentToLocalTime(x.schedule),
            resourceId: x.instanceId,
            ec2ForceToReboot: forceToReboot,
            remainingRetryCount: 1,
            TTL: 0,
            lastModified: ""
        };
    });
};
/**
 * EC2インスタンスのタグ情報からEC2起動・停止タスクを生成し、さらにその10分後にステータスチェックタスクを生成する
 * @param instances EC2インスタンスのリスト
 * @param hours タスクを生成する範囲
 * @param now タスク生成の基準日時
 */
exports.generateEC2StartStopAMITasks = (instances, hours, now) => {
    const start = instances.map(x => util.generateTask(x, "AutoStartSchedule", "StartEC2", hours, now));
    const stop = instances.map(x => util.generateTask(x, "AutoStopSchedule", "StopEC2", hours, now));
    const source = start.flat().concat(stop.flat());
    // 起動スケジュール時刻のしばらく後にこれだったらおかしい
    const statusList1 = [toolbox.ec2.StatusCode.STOPPED, toolbox.ec2.StatusCode.PENDING];
    // 停止スケジュール時刻のしばらく後にこれだったらおかしい
    const statusList2 = [toolbox.ec2.StatusCode.RUNNING, toolbox.ec2.StatusCode.STOPPING];
    return source
        .map(x => {
        const startStop = {
            key: "",
            task: x.task,
            resourceType: "EC2",
            scheduledTime: util.formatMomentToLocalTime(x.schedule),
            resourceId: x.instanceId,
            remainingRetryCount: 2,
            TTL: 0,
            lastModified: ""
        };
        const ten_minutes_after = moment_1.default(x.schedule).add(10, "minute");
        const statusCheck = {
            key: "",
            task: "EC2StatusCheck",
            resourceType: "EC2",
            scheduledTime: util.formatMomentToLocalTime(ten_minutes_after),
            resourceId: x.instanceId,
            remainingRetryCount: 1,
            statusIsNot: x.task === "StartEC2" ? statusList1 : statusList2,
            TTL: 0,
            lastModified: ""
        };
        return [startStop, statusCheck];
    })
        .flat();
};
exports.generateTasks = async (hours, now) => {
    const allInstances = await toolbox.ec2.getAllInstances(ec2);
    let tasks = [];
    tasks = tasks.concat(exports.generateEC2StartStopAMITasks(allInstances, hours, now));
    tasks = tasks.concat(exports.generateAmiRegistrationTasks(allInstances, true, hours, now));
    tasks = tasks.concat(exports.generateAmiRegistrationTasks(allInstances, false, hours, now));
    return tasks;
};
