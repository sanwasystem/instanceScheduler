"use strict";
/**
 * RDS起動・停止のタスクを生成する
 */
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const AWS = __importStar(require("aws-sdk"));
const env = __importStar(require("../env/index"));
const toolbox = __importStar(require("aws-toolbox"));
const util = __importStar(require("../util"));
const rds = new AWS.RDS({ region: env.region });
/**
 * 与えたインスタンスとタグ名からタスクを生成する。何もすることがなければ空の配列を返す
 * @param instance インスタンス
 * @param tagName "AutoStopSchedule"など
 * @param taskName
 * @param hours
 * @param now
 */
function generateTask(instance, tagName, taskName, hours, now) {
    const cronExperssion = (instance.Tag[tagName] || "").replace(/@/g, "*");
    if (!util.validateCronExpression(cronExperssion)) {
        return [];
    }
    return util.generateInterval(cronExperssion, hours, now).map(schedule => {
        return {
            identifier: instance.DBInstanceIdentifier,
            task: taskName,
            schedule: schedule
        };
    });
}
/**
 * RDSインスタンスのタグ情報からRDSの起動・停止タスクを生成する
 * @param instances
 * @param hours
 * @param now
 */
exports._generateRDSStartStopTasks = (instances, hours, now) => {
    const start = instances.map(x => generateTask(x, "AutoStartSchedule", "StartRDS", hours, now));
    const stop = instances.map(x => generateTask(x, "AutoStopSchedule", "StopRDS", hours, now));
    const source = start.flat().concat(stop.flat());
    return source.map(x => {
        return {
            key: "",
            task: x.task,
            resourceType: "RDS",
            scheduledTime: util.formatMomentToLocalTime(x.schedule),
            resourceId: x.identifier,
            remainingRetryCount: 2,
            TTL: 0,
            lastModified: ""
        };
    });
};
exports.generateTasks = async (hours, now) => {
    const allInstances = await toolbox.rds.getAllInstances(rds);
    if (allInstances === null) {
        throw new Error("DBインスタンス取得に失敗しました");
    }
    return exports._generateRDSStartStopTasks(allInstances, hours, now);
};
