"use strict";
/**
 * AMIタグ追加のタスクを生成する
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const moment_1 = __importDefault(require("moment"));
const util = __importStar(require("../util"));
exports.generate = (instance, amiId, forceToReboot) => {
    const execTime = moment_1.default().add(5, "minute");
    const amiData = util.generateAmiInfo(instance, forceToReboot);
    return {
        key: "",
        task: "AddAmiTag",
        scheduledTime: util.formatMomentToLocalTime(execTime),
        resourceId: amiId,
        resourceType: "AMI",
        tags: [
            { Key: "InstanceId", Value: instance.InstanceId },
            { Key: "ExpiresAt", Value: amiData.expiresAt },
            { Key: "Name", Value: amiData.nameJp },
            { Key: "ImageType", Value: "AutomatedSnapshot" }
        ],
        remainingRetryCount: 2,
        TTL: 0,
        lastModified: "2020-02-04T09:59:00+09:00"
    };
};
