"use strict";
/**
 * EC2起動・停止
 */
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const AWS = __importStar(require("aws-sdk"));
const env = __importStar(require("../env/index"));
const toolbox = __importStar(require("aws-toolbox"));
const util = __importStar(require("../util"));
const ec2_1 = require("aws-toolbox/dist/src/ec2");
const ec2 = new AWS.EC2({ region: env.region });
exports.TEST_IDS = {
    EC2_ID_NOTFOUND: "i-NotFound",
    EC2_ID_RUNNING: "i-Running",
    EC2_ID_STOPPED: "i-Stopped",
    EC2_ID_SHUTTINGDOWN: "i-shuttingDown"
};
const isTestId = (id) => {
    return [
        exports.TEST_IDS.EC2_ID_NOTFOUND,
        exports.TEST_IDS.EC2_ID_RUNNING,
        exports.TEST_IDS.EC2_ID_STOPPED,
        exports.TEST_IDS.EC2_ID_SHUTTINGDOWN
    ].includes(id);
};
/**
 * テスト用のインスタンス情報を返す
 * @param instanceId テスト用インスタンスIDのいずれか
 */
const getTestInstance = (instanceId) => {
    const result = {
        InstanceId: instanceId,
        InstanceType: "xxx",
        State: { Code: 0, Name: "" },
        VpcId: "vpc-12345678",
        BlockDeviceMappings: [],
        SecurityGroups: [],
        SubnetId: "subnet-12345678",
        Tags: [
            { Key: "Name", Value: "Test" },
            { Key: "Description", Value: "Test test test" }
        ],
        Tag: { Name: "Test", Description: "Test test test" },
        NameTag: "Test",
        DescriptionTag: "Test test test",
        isDetailedMonitoringEnabled: false,
        IsRunning: true,
        IpAddress: "0.0.0.0"
    };
    switch (instanceId) {
        case exports.TEST_IDS.EC2_ID_NOTFOUND:
            return null;
        case exports.TEST_IDS.EC2_ID_RUNNING:
            result.State = { Code: ec2_1.StatusCode.RUNNING, Name: "running" };
            return result;
        case exports.TEST_IDS.EC2_ID_STOPPED:
            result.State = { Code: ec2_1.StatusCode.STOPPED, Name: "stopped" };
            return result;
        case exports.TEST_IDS.EC2_ID_SHUTTINGDOWN:
            result.State = { Code: ec2_1.StatusCode.SHUTTINGDOWN, Name: "shutting_down" };
            return result;
        default:
            throw new Error("不正な値が渡されました（内部エラー）");
    }
};
/**
 * EC2IDでEC2インスタンスを探して返す。見つからなかった場合、エラーが起きた場合はnullを返す。
 * テスト用インスタンスIDを渡すとAWS APIを呼ばず内部で作成したオブジェクトを返す
 */
const getInstanceById = async (instanceId) => {
    if ([exports.TEST_IDS.EC2_ID_NOTFOUND, exports.TEST_IDS.EC2_ID_RUNNING, exports.TEST_IDS.EC2_ID_SHUTTINGDOWN, exports.TEST_IDS.EC2_ID_STOPPED].includes(instanceId)) {
        console.log("テスト用IDが渡されました");
        return getTestInstance(instanceId);
    }
    try {
        console.log(`EC2 ${instanceId} を取得します`);
        return toolbox.ec2.getInstanceById(ec2, instanceId);
    }
    catch (e) {
        // 原因の如何に関わらずnullを返す
        console.error(e);
        return null;
    }
};
/**
 * 与えられたタスクの種別（起動・停止）と、インスタンスの現在の状態とを比較し、何をすべきかを返す。
 * テスト用インスタンスIDでもここでは"skip"ではなく正しい値が返る。
 */
const checkStatus = async (task) => {
    const instance = await getInstanceById(task.resourceId);
    if (instance === null) {
        return ["error", `インスタンス取得時にエラー`];
    }
    if (env.dryRun) {
        return ["skip", "dryRun"];
    }
    if (task.task === "StartEC2") {
        switch (instance.State.Code) {
            case ec2_1.StatusCode.STOPPED:
                return ["start", ""];
            case ec2_1.StatusCode.RUNNING:
                return ["skip", "インスタンスが既に起動していた"];
            case ec2_1.StatusCode.PENDING:
                return ["skip", "インスタンスが既に起動中の状態"];
            default:
                return ["skip", `インスタンスの状態が${instance.State.Code}`];
        }
    }
    if (task.task == "StopEC2") {
        switch (instance.State.Code) {
            case ec2_1.StatusCode.RUNNING:
                return ["stop", ""];
            case ec2_1.StatusCode.STOPPED:
                return ["skip", "インスタンスが既に停止していた"];
            case ec2_1.StatusCode.STOPPING:
                return ["skip", "インスタンスが既に停止中の状態"];
            default:
                return ["skip", `インスタンスの状態が${instance.State.Code}`];
        }
    }
    throw new Error("ここには来ない");
};
/**
 * EC2を起動・停止する
 */
exports.startStop = async (task) => {
    const statusCheckResult = await checkStatus(task);
    switch (statusCheckResult[0]) {
        case "error":
            return {
                result: "ERROR",
                reason: `何もせずに終了します。理由: ${statusCheckResult[1]}`
            };
        case "skip":
            return {
                result: "OK",
                reason: `何もせずに終了します。理由: ${statusCheckResult[1]}`
            };
        case "stop":
        case "start":
            try {
                const startIfTrue = statusCheckResult[0] === "start";
                console.log(`EC2ID ${task.resourceId} を${startIfTrue ? "起動" : "停止"}します...`);
                if (isTestId(task.resourceId)) {
                    console.log("テスト用IDなので何もせずに終了します");
                    return {
                        result: "OK",
                        reason: "テスト用ID"
                    };
                }
                const result = await toolbox.ec2.startStopInstance(ec2, task.resourceId, startIfTrue ? "START" : "STOP");
                switch (result[0]) {
                    case "error":
                        return { result: "ERROR", reason: result[1] };
                    case "nothingToDo":
                        return { result: "OK", reason: "nothing to do" }; // 既にチェック済みなのでここには来ない
                    case "ok":
                        return { result: "OK", reason: "OK" };
                    case "timeout":
                        return { result: "RETRY", reason: "規定の時間内に状態が変わりませんでした" };
                    case "skip":
                        return { result: "OK", reason: "nothing to do" }; // 既にチェック済みなのでここには来ない
                    default:
                        throw new Error("");
                }
            }
            catch (e) {
                console.error(e);
                return {
                    result: "RETRY",
                    reason: e
                };
            }
        default:
            return util.neverComesHere(statusCheckResult[0]);
    }
};
