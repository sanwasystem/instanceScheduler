"use strict";
/**
 * RDS起動・停止を示すレコードを処理する
 */
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const AWS = __importStar(require("aws-sdk"));
const env = __importStar(require("../env/index"));
const util = __importStar(require("../util"));
const STATE_RUNNING = "available";
const STATE_STOPPED = "stopped";
exports.TEST_RDS_NOTFOUND = "rds_notFound";
exports.TEST_RDS_RUNNING = "rds_running";
exports.TEST_RDS_STOPPED = "rds_stopped";
const rds = new AWS.RDS({ region: env.region });
const isTestId = (name) => {
    return [exports.TEST_RDS_NOTFOUND, exports.TEST_RDS_RUNNING, exports.TEST_RDS_STOPPED].includes(name);
};
/**
 * RDSインスタンスを探して、起動状態を文字列で返す。見つからないかエラーが起きたらnullを返す
 */
const getDbInstanceStateById = async (name) => {
    switch (name) {
        case exports.TEST_RDS_NOTFOUND:
            console.log("テスト用IDが見つかりました。見つからなかったことにします");
            return null;
        case exports.TEST_RDS_RUNNING:
            console.log("テスト用IDが見つかりました。起動中だったことにします");
            return STATE_RUNNING;
        case exports.TEST_RDS_STOPPED:
            console.log("テスト用IDが見つかりました。停止中だったことにします");
            return STATE_STOPPED;
    }
    if (isTestId(name)) {
        throw new Error("ここに来るのはおかしい（内部エラー）");
    }
    try {
        const data = await rds.describeDBInstances({ DBInstanceIdentifier: name }).promise();
        if (!Array.isArray(data.DBInstances) || data.DBInstances.length == 0) {
            return null;
        }
        else {
            return data.DBInstances[0].DBInstanceStatus || "";
        }
    }
    catch (e) {
        console.error(e);
        return null;
    }
};
const startRds = async (instanceState, instanceId) => {
    try {
        if (instanceState !== STATE_STOPPED) {
            return {
                result: "OK",
                reason: `RDSインスタンス ${instanceId} は停止状態(${STATE_STOPPED})ではなかったので何もしません(${instanceState})`
            };
        }
        console.log(`RDSインスタンス ${instanceId} を起動します`);
        await rds.startDBInstance({ DBInstanceIdentifier: instanceId }).promise();
        return {
            result: "OK",
            reason: "起動しました"
        };
    }
    catch (e) {
        console.error(e);
        return {
            result: "ERROR",
            reason: e.toString()
        };
    }
};
const stoptRds = async (instanceState, instanceId) => {
    try {
        if (instanceState !== STATE_RUNNING) {
            return {
                result: "OK",
                reason: `RDSインスタンス ${instanceId} は起動中(${STATE_RUNNING})ではなかったので何もしません(${instanceState})`
            };
        }
        console.log(`RDSインスタンス ${instanceId} を停止します`);
        await rds.stopDBInstance({ DBInstanceIdentifier: instanceId }).promise();
        return {
            result: "OK",
            reason: "停止しました"
        };
    }
    catch (e) {
        console.error(e);
        return {
            result: "ERROR",
            reason: e.toString()
        };
    }
};
/**
 * RDSインスタンスを起動・停止する
 */
exports.startStop = async (task) => {
    if (env.dryRun) {
        return {
            result: "OK",
            reason: "dryRun"
        };
    }
    const instanceState = await getDbInstanceStateById(task.resourceId);
    if (instanceState === null) {
        return {
            result: "ERROR",
            reason: "インスタンスが見つからないか取得に失敗した"
        };
    }
    if (isTestId(task.resourceId)) {
        return {
            result: "OK",
            reason: "テスト用IDなので何もしません"
        };
    }
    switch (task.task) {
        case "StartRDS":
            return await startRds(instanceState, task.resourceId);
        case "StopRDS":
            return await stoptRds(instanceState, task.resourceId);
        default:
            return util.neverComesHere(task.task);
    }
};
