"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const ec2startStop = __importStar(require("./ec2startStop"));
const ami1 = __importStar(require("./amiRegistration"));
const ami2 = __importStar(require("./amiModification"));
const rds = __importStar(require("./rds"));
exports.processTask = async (task) => {
    switch (task.task) {
        case "StartEC2":
            return await ec2startStop.startStop(task);
        case "StopEC2":
            return await ec2startStop.startStop(task);
        case "RegisterAmi":
            return await ami1.createAMI(task);
        case "DeregisterAmi":
            return await ami2.deleteAmi(task);
        case "AddAmiTag":
            return await ami2.addTags(task);
        case "StartRDS":
            return await rds.startStop(task);
        case "StopRDS":
            return await rds.startStop(task);
        default:
            throw new Error("想定していないタスクが来ました");
    }
};
