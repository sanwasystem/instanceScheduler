"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv = __importStar(require("dotenv"));
dotenv.config();
/**
 * 指定した名前の環境変数を取得する。未定義なら例外をスローする
 * @param name 名前
 */
exports.getEnv = (name) => {
    const result = process.env[name];
    if (result === undefined) {
        throw new Error(`環境変数 '${name}' が定義されていません`);
    }
    return result;
};
/**
 * Slackにメッセージを送るLambdaの名前
 */
exports.ClientLambdaName = exports.getEnv("SlackLambdaName");
/**
 * 通常のメッセージを送るSlackチャンネル名
 */
exports.Channel = exports.getEnv("SlackChannel");
/**
 * エラーメッセージを送るSlackチャンネル名
 */
exports.ErrorChannel = exports.getEnv("SlackErrorChannel");
/**
 * アカウントの名前。「本番」「検証」など。Slack通知の名前に使う
 */
exports.AccountNickName = exports.getEnv("AccountNickName");
/**
 * アイコン
 */
exports.Icon = exports.getEnv("SlackIcon");
