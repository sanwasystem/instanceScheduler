"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv = __importStar(require("dotenv"));
dotenv.config();
/**
 * 指定した名前の環境変数を取得する。未定義なら例外をスローする
 * @param name 名前
 */
exports.getEnv = (name) => {
    const result = process.env[name];
    if (result === undefined) {
        throw new Error(`環境変数 '${name}' が定義されていません`);
    }
    return result;
};
exports.getEnvAsNumber = (name) => {
    const val = exports.getEnv(name);
    const number = +val;
    if (val != val) {
        throw new Error(`環境変数 '${name}' が数値ではありません`);
    }
    return number;
};
/**
 * スケジュールを格納するDynamoDBのテーブル名
 */
exports.ScheduleTableName = exports.getEnv("ScheduleTableName");
/**
 * dryRunモード。dryRun環境変数に明示的に「1」がセットされていたときにのみ有効
 */
exports.dryRun = process.env.dryRun == "1";
/**
 * UTF offset
 */
exports.utfOffset = +exports.getEnvAsNumber("utfOffset");
/**
 * DynamoDBにレコードを登録するときのTTL。3なら登録後72時間すると未処理でも自動的に削除される
 */
exports.RecordTTLInDays = exports.getEnvAsNumber("RecordTTLInDays");
/**
 * スケジューラーが動作しているリージョン
 */
exports.region = exports.getEnv("region");
/**
 * AWSアカウント番号
 */
exports.AccountNo = exports.getEnv("AccountNo");
