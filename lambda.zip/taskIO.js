"use strict";
/**
 * スケジュールを示すレコードを取得・登録・削除する
 */
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const AWS = __importStar(require("aws-sdk"));
const env = __importStar(require("./env/index"));
const moment_1 = __importDefault(require("moment"));
const Types = __importStar(require("./types/task"));
const toolbox = __importStar(require("aws-toolbox"));
const dynamo = new AWS.DynamoDB.DocumentClient({ region: env.region });
/**
 * 与えられたタスクの実行日時が到来しているならtrueを返す
 * @param task
 * @param dateTime
 */
exports.hasExectimeArrived = (task, dateTime) => {
    // 日時をパースして既に実行日時が到来しているものを返す。タイムゾーンが突然変わっていても問題なし
    try {
        const scheduledTime = moment_1.default(task.scheduledTime);
        return dateTime.diff(scheduledTime) >= 0;
    }
    catch (e) {
        console.error("日付のパースに失敗する変なレコードが渡されました。無視します");
        console.error(task);
        return false;
    }
};
/**
 * 指定した日時以前のタスクを取得する
 * @param dateTime momentのインスタンス。省略した場合は現在日時
 */
exports.getTasks = async (dateTime) => {
    // とりあえずDynamoDBから全レコードを取得する。レコードの数は限られているので問題にはならない
    const allTasks = await toolbox.dynamo.getAllRecords(dynamo, env.ScheduleTableName, Types.isTaskRecordOnDb);
    // 基準となる日時が省略されたら現在時刻
    const _dateTime = (dateTime !== null && dateTime !== void 0 ? dateTime : moment_1.default());
    return allTasks.filter(x => exports.hasExectimeArrived(x, _dateTime));
};
/**
 * タスクIDを指定してタスクを1件取得する。見つからなかった場合は例外をスローする
 * @param taskId
 */
exports.getTaskById = async (taskId) => {
    return toolbox.dynamo.getSingleRecord(dynamo, env.ScheduleTableName, "key", taskId, Types.isTaskRecordOnDb);
};
/**
 * 与えたスケジュールをDBに登録する。key, TTL, lastModifiedは上書きする
 */
exports.putTask = async (task) => {
    task.key = [task.task, task.resourceId, task.scheduledTime].join("_");
    task.TTL = moment_1.default().unix() + env.RecordTTLInDays * 24 * 3600;
    task.lastModified = moment_1.default()
        .utcOffset(env.utfOffset)
        .format();
    if (env.dryRun) {
        console.log("dryRunが指定されていたのでスケジュール登録はスキップします。key, TTL, lastModified上書きは実行します");
        return;
    }
    await dynamo.put({ TableName: env.ScheduleTableName, Item: task }).promise();
};
/**
 * 与えたタスクを削除する
 * @param task
 */
exports.removeTask = async (task) => {
    if (env.dryRun) {
        console.log("スケジュール削除はスキップします");
        return;
    }
    await dynamo
        .delete({
        TableName: env.ScheduleTableName,
        Key: {
            key: task.key
        }
    })
        .promise();
};
/**
 * 与えたタスクのリトライカウンタを1減らしてタスクを更新する。
 * 0だったらレコードを削除する。
 * @param task
 */
exports.decrementRetryCount = async (task) => {
    if (env.dryRun) {
        console.log("スケジュール更新処理はスキップします");
        return;
    }
    if (task.remainingRetryCount === 0) {
        console.log("リトライカウンタは0でした。レコードを削除します");
        await exports.removeTask(task);
        return;
    }
    task.remainingRetryCount--;
    console.log(`リトライカウンタを${task.remainingRetryCount}にしてレコードを更新します`);
    await dynamo
        .put({
        TableName: env.ScheduleTableName,
        Item: task
    })
        .promise();
};
