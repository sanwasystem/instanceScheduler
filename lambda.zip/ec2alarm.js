"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * AlwaysRunningタグに「true」と書いてあって、かつ状態がrunningでないものを探す
 */
const AWS = __importStar(require("aws-sdk"));
const env = __importStar(require("./env/index"));
const util = __importStar(require("./util"));
const toolbox = __importStar(require("aws-toolbox"));
const moment_1 = __importDefault(require("moment"));
const ec2 = new AWS.EC2({ region: env.region });
/**
 * AlwaysRunningタグに「true」と書いてあって、スケジュールを算出すると起動中のはずで、かつ状態がrunningでもpendingでもないものを探す
 * @param ec2Instances
 */
exports._getEc2ToAlarm = (ec2Instances, now) => {
    return ec2Instances.filter(x => {
        var _a;
        const alwaysRunning = ((_a = x.Tag.AlwaysRunning) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === "true";
        const scheduledStatus = util.getScheduledStatus(x.Tag.AutoStartSchedule, x.Tag.AutoStopSchedule, moment_1.default(now).add(1, "minutes"));
        const isRunning = [toolbox.ec2.StatusCode.RUNNING, toolbox.ec2.StatusCode.PENDING].includes(x.State.Code);
        // console.log(`alwaysRunning=${alwaysRunning}, isRunning=${isRunning}, scheduledStatus=${scheduledStatus}`);
        return alwaysRunning && scheduledStatus === "RUNNING" && !isRunning;
    });
};
exports.getEc2ToAlarm = async () => {
    const ec2Instances = await toolbox.ec2.getAllInstances(ec2);
    return exports._getEc2ToAlarm(ec2Instances, moment_1.default());
};
