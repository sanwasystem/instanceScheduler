"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// InstanceScheduler v1.1.1
// https://github.com/sanwasystem/instance-scheduler
/* eslint-disable @typescript-eslint/no-unused-vars */
const AWS = __importStar(require("aws-sdk"));
const env = __importStar(require("./env/index"));
const index_1 = require("./taskGenerator/index");
const taskProcessor_1 = require("./taskProcessor");
const taskIO = __importStar(require("./taskIO"));
const slack = __importStar(require("./slack"));
const ec2alarm = __importStar(require("./ec2alarm"));
const util = __importStar(require("./util"));
const _ = __importStar(require("lodash"));
const moment_1 = __importDefault(require("moment"));
const lambda = new AWS.Lambda({ region: env.region });
/**
 * 今後25時間分のタスクを生成し、DynamoDBに登録する
 */
exports.registerTasks = async (event, context) => {
    const tasks = await index_1.generateTasks(25, moment_1.default());
    const grouped = _.groupBy(tasks, "task");
    const counts = Object.keys(grouped).map(x => `${x}: ${grouped[x].length} 件`);
    await slack.log(`今後25時間分の${tasks.length}件のタスクを生成しました\n` + counts.join("\n"));
    for (const task of tasks) {
        console.log(task);
        await taskIO.putTask(task);
    }
    console.log("タスクの登録が完了しました");
    return true;
};
/**
 * 1. 起動しているはずのEC2が停止していたら（runnningではなかったら）アラートを出す
 * 2. D2ynamoDBから実行すべきスケジュールを取得して別のLambdaに渡して処理する
 */
exports.processTasks = async (event, context) => {
    // 処理すべきタスクを取得し、別Lambdaに渡して処理させる
    const tasks = await taskIO.getTasks();
    for (const task of tasks) {
        console.log(`次のタスクを実行します: ${task.key}`);
        await lambda
            .invoke({
            FunctionName: "InstanceScheduler_TaskProcessor",
            InvocationType: "Event",
            Payload: JSON.stringify({ taskId: task.key })
        })
            .promise();
    }
    console.log("タスクの実行は完了しました。EC2起動チェックを行います");
    // EC2を全部取得する
    const alarm = await ec2alarm.getEc2ToAlarm();
    if (alarm.length > 0) {
        const lines = alarm.map(x => `* ID: ${x.InstanceId} Name: ${x.NameTag} IpAddress: ${x.IpAddress}`);
        const message = ["AlwaysRunning（常時起動）タグがtrueなのに停止しているインスタンスがあります", ...lines].join("\r\n");
        await slack.error(message);
    }
};
/**
 * 引数taksIdでDynamoDBを検索し、タスクを処理する
 */
exports.processTask = async (event, context) => {
    const taskId = event.taskId;
    if (typeof taskId !== "string") {
        throw new Error("引数が指定されていません");
    }
    const task = await taskIO.getTaskById(taskId);
    console.log("次のタスクを処理します:");
    console.log(task);
    const result = await taskProcessor_1.processTask(task);
    switch (result.result) {
        case "OK":
            await slack.log(`タスクの内容: ${JSON.stringify(task)}, 結果: ${result.result}, 理由: ${result.reason}`);
            await taskIO.removeTask(task);
            return true;
        case "ERROR":
            await slack.error(`タスクの内容: ${JSON.stringify(task)}, 結果: ${result.result}, 理由: ${result.reason}`);
            await taskIO.removeTask(task);
            return false;
        case "RETRY":
            await slack.error(`タスクの内容: ${JSON.stringify(task)}, 結果: ${result.result}, 理由: ${result.reason}`);
            await taskIO.decrementRetryCount(task);
            return false;
        default:
            return util.neverComesHere(result.result);
    }
};
