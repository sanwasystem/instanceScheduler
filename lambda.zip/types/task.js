"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const _isTaskRecordBase = (arg) => {
    if (!arg) {
        return false;
    }
    if (typeof arg !== "object") {
        return false;
    }
    if (typeof arg.key !== "string") {
        return false;
    }
    if (typeof arg.TTL !== "number") {
        return false;
    }
    if (typeof arg.resourceId !== "string") {
        return false;
    }
    if (typeof arg.remainingRetryCount !== "number") {
        return false;
    }
    if (typeof arg.scheduledTime !== "string") {
        return false;
    }
    if (typeof arg.lastModified !== "string") {
        return false;
    }
    return true;
};
exports.isStartStopEC2 = (_arg) => {
    if (!_isTaskRecordBase(_arg)) {
        return false;
    }
    const arg = _arg;
    if (arg.task !== "StopEC2" && arg.task !== "StartEC2") {
        return false;
    }
    if (arg.resourceType != "EC2") {
        return false;
    }
    if (!/^i-.*$/.test(arg.resourceId)) {
        return false;
    }
    return true;
};
exports.isRegisterAmi = (_arg) => {
    if (!_isTaskRecordBase(_arg)) {
        return false;
    }
    const arg = _arg;
    if (arg.task !== "RegisterAmi") {
        return false;
    }
    if (arg.resourceType != "EC2") {
        return false;
    }
    if (typeof arg.ec2ForceToReboot != "boolean") {
        return false;
    }
    if (!/^i-.*$/.test(arg.resourceId)) {
        return false;
    }
    return true;
};
exports.isAddAmiTag = (_arg) => {
    if (!_isTaskRecordBase(_arg)) {
        return false;
    }
    const arg = _arg;
    if (arg.task !== "AddAmiTag") {
        return false;
    }
    if (arg.resourceType != "AMI") {
        return false;
    }
    if (!Array.isArray(arg.tags)) {
        return false;
    }
    if (!/^ami-.*$/.test(arg.resourceId)) {
        return false;
    }
    for (const item of arg.tags) {
        if (typeof item.Key !== "string") {
            return false;
        }
        if (typeof item.Value !== "string") {
            return false;
        }
    }
    return true;
};
exports.isDeregisterAmi = (_arg) => {
    if (!_isTaskRecordBase(_arg)) {
        return false;
    }
    const arg = _arg;
    if (arg.task !== "DeregisterAmi") {
        return false;
    }
    if (arg.resourceType != "AMI") {
        return false;
    }
    if (!Array.isArray(arg.snapshotIds)) {
        return false;
    }
    if (!/^ami-.*$/.test(arg.resourceId)) {
        return false;
    }
    for (const item of arg.snapshotIds) {
        if (typeof item !== "string") {
            return false;
        }
    }
    return true;
};
exports.isStartStopRDS = (_arg) => {
    if (!_isTaskRecordBase(_arg)) {
        return false;
    }
    const arg = _arg;
    if (arg.task !== "StopRDS" && arg.task !== "StartRDS") {
        return false;
    }
    if (arg.resourceType != "RDS") {
        return false;
    }
    return true;
};
exports.isEC2StatusCheck = (_arg) => {
    if (!_isTaskRecordBase(_arg)) {
        return false;
    }
    const arg = _arg;
    if (arg.task !== "EC2StatusCheck") {
        return false;
    }
    if (arg.resourceType !== "EC2") {
        return false;
    }
    if (!Array.isArray(arg.statusIsNot)) {
        return false;
    }
    if (arg.statusIsNot.some((x) => typeof x !== "number")) {
        return false;
    }
    return true;
};
exports.isTaskRecordOnDb = (arg) => {
    return (exports.isStartStopEC2(arg) ||
        exports.isRegisterAmi(arg) ||
        exports.isAddAmiTag(arg) ||
        exports.isDeregisterAmi(arg) ||
        exports.isStartStopRDS(arg) ||
        exports.isEC2StatusCheck(arg));
};
